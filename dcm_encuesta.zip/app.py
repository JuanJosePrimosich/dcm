import streamlit as st
import pandas as pd
import random

# Inicializar estado
if "screen" not in st.session_state:
    st.session_state.screen = "inicio"
if "current_question" not in st.session_state:
    st.session_state.current_question = 0
if "responses" not in st.session_state:
    st.session_state.responses = []

# Datos simulados de atributos por alternativa
alternatives = [
    {"nombre": "Auto A", "precio": "$20.000", "consumo": "6L/100km", "diseño": "Moderno", "garantía": "3 años"},
    {"nombre": "Auto B", "precio": "$18.000", "consumo": "5L/100km", "diseño": "Clásico", "garantía": "2 años"},
    {"nombre": "Auto C", "precio": "$22.000", "consumo": "7L/100km", "diseño": "Deportivo", "garantía": "5 años"},
]

# Crear bloques (5 bloques de 3 alternativas, aleatorizados)
def generate_blocks(n_blocks=5):
    blocks = []
    for _ in range(n_blocks):
        block = random.sample(alternatives, 3)
        blocks.append(block)
    return blocks

if "blocks" not in st.session_state:
    st.session_state.blocks = generate_blocks()

# Función para reiniciar
def reset_app():
    st.session_state.screen = "inicio"
    st.session_state.current_question = 0
    st.session_state.responses = []
    st.session_state.blocks = generate_blocks()

# Pantalla de inicio con consentimiento informado
if st.session_state.screen == "inicio":
    st.title("Encuesta de Elección Discreta")
    st.subheader("Consentimiento Informado")
    st.write("""
        Esta encuesta forma parte de un estudio académico. Su participación es voluntaria y anónima.
        Los datos recolectados serán utilizados únicamente con fines de investigación.
    """)
    if st.button("Acepto participar"):
        st.session_state.screen = "preguntas"

# Pantalla de preguntas
elif st.session_state.screen == "preguntas":
    st.title(f"Escenario {st.session_state.current_question + 1} de 5")
    block = st.session_state.blocks[st.session_state.current_question]

    for i, alt in enumerate(block):
        st.markdown(f"### Alternativa {i+1}")
        st.write(f"**Nombre:** {alt['nombre']}")
        st.write(f"**Precio:** {alt['precio']}")
        st.write(f"**Consumo:** {alt['consumo']}")
        st.write(f"**Diseño:** {alt['diseño']}")
        st.write(f"**Garantía:** {alt['garantía']}")

    choice = st.radio("¿Cuál elegirías?", [f"Alternativa {i+1}" for i in range(3)])

    if st.button("Siguiente"):
        st.session_state.responses.append({
            "bloque": st.session_state.current_question + 1,
            "elección": choice
        })
        st.session_state.current_question += 1
        if st.session_state.current_question >= len(st.session_state.blocks):
            st.session_state.screen = "fin"

# Pantalla final
elif st.session_state.screen == "fin":
    st.title("¡Gracias por participar!")
    df = pd.DataFrame(st.session_state.responses)
    st.write("Tus respuestas:")
    st.dataframe(df)
    df.to_csv("respuestas.csv", index=False)
    st.download_button("Descargar respuestas", data=df.to_csv(index=False).encode(), file_name="respuestas.csv", mime="text/csv")
    if st.button("Volver a comenzar"):
        reset_app()