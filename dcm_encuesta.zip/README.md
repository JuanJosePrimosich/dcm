
# Encuesta DCM (Discrete Choice Modeling)

Aplicación en Streamlit para realizar una encuesta de elección discreta con consentimiento informado y múltiples bloques.

## Instrucciones para correr localmente

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Despliegue en Streamlit Cloud

1. Subí los archivos a un nuevo repositorio en GitHub.
2. Ingresá a https://streamlit.io/cloud y logueate.
3. Creá una nueva app, seleccioná el repo y `app.py` como archivo principal.
4. ¡Listo! Accedé al link público generado.
